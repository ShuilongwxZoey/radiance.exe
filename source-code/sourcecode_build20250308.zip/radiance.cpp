// radiance.cpp : ���ļ����� "main" ����������ִ�н��ڴ˴���ʼ��������
//

#pragma warning(disable: 4995)
#pragma comment(lib, "Dwmapi.lib")
#include <dwmapi.h>
#include <windows.h>
#include <windowsx.h>
#include <cmath>
#include <stdio.h>
#include <tchar.h>
#include <ShlObj.h>
#include "Bytebeats.h"
#include "Payloads.h"
HANDLE CurrentPayloadThread1 = NULL, CurrentPayloadThread2 = NULL, CurrentPayloadThread3 = NULL, CurrentPayloadThread4 = NULL, CurrentPayloadThread5 = NULL, CurrentPayloadThread6 = NULL, CurrentPayloadThread7 = NULL, CurrentPayloadThread8 = NULL, CurrentPayloadThread9 = NULL;
HANDLE CPThread1 = NULL, CPThread2 = NULL, CPThread3 = NULL, CPThread4 = NULL;

DWORD WINAPI fakeerror(LPVOID lpParam){
    MessageBoxA(NULL, "Failed to connect to https://www.getrickrolled.com, Please check your Internet Connection and try again.", "An error has occurred.", MB_ICONERROR);
    return 0;
}

DWORD WINAPI dumb(LPVOID lpParam) {
    while (true) {
        MessageBoxA(NULL, "A ray of radiance shots into your eyes and your destroyed computer.", "radiance.exe - System Warning", MB_ICONWARNING | MB_RETRYCANCEL);
    }
    return 0;
}

int StopThread(HANDLE thread) {
    TerminateThread(thread, 0);
    CloseHandle(thread);
    return 0;
}

BOOL PayloadControl(BOOL Run, int Num1, int Num2) {
    if (Run == true) {
        if (Num1 == 1) {
            if (Num2 == 1) { sound1(); CurrentPayloadThread1 = CreateThread(0, 0, Payload1_num1, 0, 0, 0); }
        }
        else if (Num1 == 2) {
            if (Num2 == 1) { sound2(); CurrentPayloadThread1 = CreateThread(0, 0, Payload2_num1, 0, 0, 0); }
            else if (Num2 == 2) { CurrentPayloadThread2 = CreateThread(0, 0, Payload2_num2, 0, 0, 0); }
            else if (Num2 == 3) { CurrentPayloadThread3 = CreateThread(0, 0, Payload2_num3, 0, 0, 0); }
            else if (Num2 == 4) { CurrentPayloadThread4 = CreateThread(0, 0, Payload2_num4, 0, 0, 0); }
        }
        else if (Num1 == 3) {
            if (Num2 == 1) { sound3(); CurrentPayloadThread1 = CreateThread(0, 0, Payload3_num1, 0, 0, 0); }
            else if (Num2 == 2) { CurrentPayloadThread2 = CreateThread(0, 0, Payload3_num2, 0, 0, 0); }
        }
        else if (Num1 == 4) {
            if (Num2 == 1) { sound4(); CurrentPayloadThread1 = CreateThread(0, 0, Payload4_num1, 0, 0, 0); }
        }
        else if (Num1 == 5) {
            if (Num2 == 1) { sound5(); CurrentPayloadThread1 = CreateThread(0, 0, Payload5_num1, 0, 0, 0); }
            if (Num2 == 2) { CurrentPayloadThread2 = CreateThread(0, 0, Payload5_num2, 0, 0, 0); }
            if (Num2 == 3) { CurrentPayloadThread3 = CreateThread(0, 0, Payload5_num3, 0, 0, 0); }
        }
        else if (Num1 == 6) {
            if (Num2 == 1) { sound6(); CurrentPayloadThread1 = CreateThread(0, 0, Payload6_num1, 0, 0, 0); }
            if (Num2 == 2) { CurrentPayloadThread2 = CreateThread(0, 0, Payload6_num2, 0, 0, 0); }
            if (Num2 == 3) { CurrentPayloadThread3 = CreateThread(0, 0, Payload6_num3, 0, 0, 0); }
            if (Num2 == 4) { CurrentPayloadThread4 = CreateThread(0, 0, Payload6_num4, 0, 0, 0); }
        }
        else if (Num1 == 7) {
            if (Num2 == 1) { sound7(); CurrentPayloadThread1 = CreateThread(0, 0, Payload7_num1, 0, 0, 0); }
        }
        else if (Num1 == 8) {
            if (Num2 == 1) { sound8(); CurrentPayloadThread1 = CreateThread(0, 0, Payload8_num1, 0, 0, 0); }
            if (Num2 == 2) { CurrentPayloadThread2 = CreateThread(0, 0, Payload8_num2, 0, 0, 0); }
            if (Num2 == 3) { CurrentPayloadThread3 = CreateThread(0, 0, Payload8_num3, 0, 0, 0); }
            if (Num2 == 4) { CurrentPayloadThread4 = CreateThread(0, 0, Payload8_num4, 0, 0, 0); }
        }
        else if (Num1 == 9) {
            if (Num2 == 1) { sound9(); CurrentPayloadThread1 = CreateThread(0, 0, Payload9_num1, 0, 0, 0); }
            if (Num2 == 2) { CurrentPayloadThread2 = CreateThread(0, 0, Payload9_num2, 0, 0, 0); }
            if (Num2 == 2) { CurrentPayloadThread3 = CreateThread(0, 0, Payload9_num3, 0, 0, 0); }
        }
        else if (Num1 == 10) {
            if (Num2 == 1) { sound10(); CurrentPayloadThread1 = CreateThread(0, 0, Payload10_num1, 0, 0, 0); }
            if (Num2 == 2) { CurrentPayloadThread2 = CreateThread(0, 0, Payload10_num2, 0, 0, 0); }
        }
        else if (Num1 == 11) {
            if (Num2 == 1) { sound11(); CurrentPayloadThread1 = CreateThread(0, 0, Payload11_num1, 0, 0, 0); }
        }
    } else {
        if (CurrentPayloadThread1 != NULL) { StopThread(CurrentPayloadThread1); }
        if (CurrentPayloadThread2 != NULL) { StopThread(CurrentPayloadThread2); }
        if (CurrentPayloadThread3 != NULL) { StopThread(CurrentPayloadThread3); }
        if (CurrentPayloadThread4 != NULL) { StopThread(CurrentPayloadThread4); }
        if (CurrentPayloadThread5 != NULL) { StopThread(CurrentPayloadThread5); }
        if (CurrentPayloadThread6 != NULL) { StopThread(CurrentPayloadThread6); }
        if (CurrentPayloadThread7 != NULL) { StopThread(CurrentPayloadThread7); }
        if (CurrentPayloadThread8 != NULL) { StopThread(CurrentPayloadThread8); }
        if (CurrentPayloadThread9 != NULL) { StopThread(CurrentPayloadThread9); }
        RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN); InvalidateRect(0, 0, 0);
        Sleep(50);
    }
    return true;
}


BOOL PayloadControl2(BOOL Run, int Num) {
    if (Run == true) {
        if (Num == 1) { CPThread1 = CreateThread(0, 0, DrawIcons, 0, 0, 0); }
        else if (Num == 2) { CPThread2 = CreateThread(0, 0, DrawCursors, 0, 0, 0); }
        else if (Num == 3) { CPThread3 = CreateThread(0, 0, DrawTexts, 0, 0, 0); }
        else if (Num == 4) { CPThread4 = CreateThread(0, 0, CursorDrawIcon, 0, 0, 0); }
    }
    else {
        if (CPThread1 != NULL) { StopThread(CPThread1); }
        if (CPThread2 != NULL) { StopThread(CPThread2); }
        if (CPThread3 != NULL) { StopThread(CPThread3); }
        if (CPThread4 != NULL) { StopThread(CPThread4); }
        Sleep(50);
    }
    return true;
}

void RunPayload() {
    int PayloadNum = 0;
    CreateThread(0, 0, fakeerror, 0, 0, 0);
    Sleep(3000);

    DwmEnableComposition(0);
    PayloadControl2(true, 4);
    PayloadControl(true, 1, 1);
    Sleep(30000); PayloadControl(false, 0, 0);

    CreateThread(0, 0, dumb, 0, 0, 0);
    for (PayloadNum = 1; PayloadNum <= 4; PayloadNum++) { PayloadControl(true, 2, PayloadNum); }
    Sleep(30000); PayloadControl(false, 0, 0);
    
    PayloadControl2(true, 1);
    PayloadControl2(true, 2);
    for (PayloadNum = 1; PayloadNum <= 2; PayloadNum++) { PayloadControl(true, 3, PayloadNum); }
    Sleep(30000); PayloadControl2(false, 0); PayloadControl(false, 0, 0);

    PayloadControl2(true, 3);
    PayloadControl2(true, 4);
    PayloadControl(true, 4, 1);
    Sleep(30000); PayloadControl2(false, 0); PayloadControl(false, 0, 0);
   
    PayloadControl2(true, 4);
    for (PayloadNum = 1; PayloadNum <= 3; PayloadNum++) { PayloadControl(true, 5, PayloadNum); }
    Sleep(30000); PayloadControl(false, 0, 0);

    PayloadControl2(true, 1);
    PayloadControl2(true, 2);
    for (PayloadNum = 1; PayloadNum <= 4; PayloadNum++) { PayloadControl(true, 6, PayloadNum); }
    Sleep(30000); PayloadControl2(false, 0); PayloadControl(false, 0, 0);

    PayloadControl(true, 7, 1);
    Sleep(30000); PayloadControl(false, 0, 0);

    PayloadControl2(true, 1);
    PayloadControl2(true, 2);
    PayloadControl2(true, 4);
    for (PayloadNum = 1; PayloadNum <= 4; PayloadNum++) { PayloadControl(true, 8, PayloadNum); }
    Sleep(30000); PayloadControl(false, 0, 0);

    for (PayloadNum = 1; PayloadNum <= 3; PayloadNum++) { PayloadControl(true, 9, PayloadNum); }
    Sleep(30000); PayloadControl(false, 0, 0);

    for (PayloadNum = 1; PayloadNum <= 2; PayloadNum++) { PayloadControl(true, 10, PayloadNum); }
    Sleep(30000); PayloadControl(false, 0, 0);

    PayloadControl2(true, 3);
    PayloadControl(true, 11, 1);
    Sleep(30000); PayloadControl2(false, 0); PayloadControl(false, 0, 0);
}

int CALLBACK WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    // This is my first time trying to no skid from other malwares.
    
    SetProcessDPIAware();
    if (MessageBoxA(NULL, "WARNING!\r\n\r\nYou are running a safety GDI malware called radiance.exe by camellia-y7x.\r\nThis malware will not destroy your computer. But it will show some cool effects on your screen and play some loud noises.\r\nIf you are running this program without the knowledge of what will this program do, Just click \"No\" to quit this malware.\r\n\r\nDo you want to execute this malware?", "First warning - radiance.exe (Unfinished Version, GDI only)", MB_YESNO | MB_ICONEXCLAMATION) == IDYES) {
        if (MessageBoxA(NULL, "LAST WARNING!\r\n\r\nBefore you decide to continue execute radiance.exe, Please make sure you are running in virtual machine or a safe environment!\r\nIf you have photosensitive epilepsy, Please don't execute this malware!\r\n\r\nDo you really want to run this malware? camellia-y7x is not responsible for any damages by using this malware!", "LAST WARNING - radiance.exe (Unfinished Version, GDI only)", MB_YESNO | MB_ICONEXCLAMATION) == IDYES) {
            RunPayload();
            ExitProcess(0);
        }
        else {
            ExitProcess(0);
        }
    }
    else {
        ExitProcess(0);
    }
}